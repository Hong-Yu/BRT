/**
 * Created by CCT on 2014/4/21.
 */


function AppendSomething() {
   console.log("11111");
}
