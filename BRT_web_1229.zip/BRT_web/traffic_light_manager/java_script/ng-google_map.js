/**
 * Created by hong on 2014/12/29.
 */
(function(){ // anonymous self-invoking function
    var app = angular.module('google.map.service', []);
    app.factory('googleMap', ['$http', '$templateCache', '$q',
        function( $http, $templateCache, $q) {
            var service = {};
            service.google_map =  CreateMap();




            return service;
        }]);
})();

function CreateMap() {
    var mapProp = {
//           center: new google.maps.LatLng(24.145010950338797, 120.67556625750512),
        center: new google.maps.LatLng(24.201648, 120.580850),
        // 24.199216, 120.558074 water
        // 24.201648, 120.580850
        zoom: 16,
        mapTypeId: google.maps.MapTypeId.ROADMAP,
        disableDefaultUI: true
    };
    map = new google.maps.Map(document.getElementById("googleMap")
        ,mapProp);
    return map;
}