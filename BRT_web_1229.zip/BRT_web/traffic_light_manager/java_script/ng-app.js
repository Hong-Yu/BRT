﻿/**
 * Created by hong on 2014/11/11.
 */
(function(){ // anonymous self-invoking function
    var app = angular.module('traffic.light.manager.app', ['http.service']);

    app.controller('LightManagerController', ['$scope', 'httpFactory', function($scope, http_service) {
        $scope.http_service = http_service;

//        $scope.ReadPermissionData = function() {
//            var promise  = http_service.PermissionLevelRead();
//            promise.then(function(data) {
//                console.log("permission data: ", data);
//                $scope.permission_data = data.data;
//            }, function(reason) {});
//        };




    }]);



    app.directive("mainCanvas", function($compile){
        console.log("html page append !");
        return{
            restrict: 'E',
            templateUrl:'traffic_light_manager/sub_page/main.html'
        }
    });
})();