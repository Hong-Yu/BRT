/**
* Created by hong on 2014/4/17.
*/

function RenewState() {
    // Public member ----------------------------------------------------------
    this.Initialize = Initialize;
    function Initialize(inputdata) {
    }
    this.set_connector = set_connector;
    function set_connector(web_socket) {
        this.connector = web_socket;
    }
    this.busData = busData;
    function busData(inpudata) {
       dataProcess(inpudata);
    }

   function dataProcess(inpudata){
      var lcn = inpudata.LCN;
      var domain_bus =$('div.divmap');
      var x = $('#circle'+lcn).offset().left;
      var y = $('#circle'+lcn).offset().top;
      var str_img = "";
      if(inpudata.Point >0 && inpudata.Point <8){ // 0~6
         if(inpudata.DIR ==0){
            switch (inpudata.Point){
               case 1:
                  str_img+='<img src="/BRT_web/live_status_sketch/images/dir_0.jpg" class="'+lcn+'01" title="BUS_id: '+inpudata.BRTID+' 接近路口中 @Point '+inpudata.Point+'" width="20px" height="20px" style="position: absolute; left: '+ (x-50) +'px; top: '+ (y-25) +'px">';
                  $('.'+lcn+'01').remove();
                  domain_bus.append(str_img);
                  break;
               case 2:
                  str_img+='<img src="/BRT_web/live_status_sketch/images/dir_0.jpg" class="'+lcn+'01" title="BUS_id: '+inpudata.BRTID+'接近路口中 @Point '+inpudata.Point+'" width="20px" height="20px" style="position: absolute; left: '+ (x-35) +'px; top: '+ (y-25) +'px">';
                  $('.'+lcn+'01').remove();
                  domain_bus.append(str_img);
                  break;
               case 3:
                  str_img+='<img src="/BRT_web/live_status_sketch/images/dir_0.jpg" class="'+lcn+'01" title="BUS_id: '+inpudata.BRTID+'接近路口中 @Point '+inpudata.Point+'" width="20px" height="20px" style="position: absolute; left: '+ (x-25) +'px; top: '+ (y-25) +'px">';
                  $('.'+lcn+'01').remove();
                  domain_bus.append(str_img);
                  break;
               case 4:
                  str_img+='<img src="/BRT_web/live_status_sketch/images/dir_0.jpg" class="'+lcn+'01" title="BUS_id: '+inpudata.BRTID+'即將通過路口中 @Point '+inpudata.Point+'" width="20px" height="20px" style="position: absolute; left: '+ (x-10) +'px; top: '+ (y-25) +'px">';
                  $('.'+lcn+'01').remove();
                  domain_bus.append(str_img);
                  break;
               case 5:
                  str_img+='<img src="/BRT_web/live_status_sketch/images/dir_0.jpg" class="'+lcn+'01" title="BUS_id: '+inpudata.BRTID+'通過路口中 @Point '+inpudata.Point+'" width="20px" height="20px" style="position: absolute; left: '+ (x-0) +'px; top: '+ (y-25) +'px">';
                  $('.'+lcn+'01').remove();
                  domain_bus.append(str_img);
                  break;
               case 6:
                  str_img+='<img src="/BRT_web/live_status_sketch/images/dir_0.jpg" class="'+lcn+'01" title="BUS_id: '+inpudata.BRTID+'已通過路口 @Point '+inpudata.Point+'" width="20px" height="20px" style="position: absolute; left: '+ (x+10) +'px; top: '+ (y-25) +'px">';
                  $('.'+lcn+'01').remove();
                  domain_bus.append(str_img);
                  break;
               case 7:
                  $('.'+lcn+'01').remove();
                  break;
            }
         }
         if(inpudata.DIR ==1){
            switch (inpudata.Point){
               case 1:
                  str_img+='<img src="/BRT_web/live_status_sketch/images/dir_1.jpg" class="'+lcn+'02" title="BUS_id: '+inpudata.BRTID+' 接近路口中 @Point '+inpudata.Point+'" width="20px" height="20px" style="position: absolute; left: '+ (x+50) +'px; top: '+ (y-45) +'px">';
                  $('.'+lcn+'02').remove();
                  domain_bus.append(str_img);
                  break;
               case 2:
                  str_img+='<img src="/BRT_web/live_status_sketch/images/dir_1.jpg" class="'+lcn+'02" title="BUS_id: '+inpudata.BRTID+'接近路口中 @Point '+inpudata.Point+'" width="20px" height="20px" style="position: absolute; left: '+ (x+35) +'px; top: '+ (y-45) +'px">';
                  $('.'+lcn+'02').remove();
                  domain_bus.append(str_img);
                  break;
               case 3:
                  str_img+='<img src="/BRT_web/live_status_sketch/images/dir_1.jpg" class="'+lcn+'02" title="BUS_id: '+inpudata.BRTID+'接近路口中 @Point '+inpudata.Point+'" width="20px" height="20px" style="position: absolute; left: '+ (x+25) +'px; top: '+ (y-45) +'px">';
                  $('.'+lcn+'02').remove();
                  domain_bus.append(str_img);
                  break;
               case 4:
                  str_img+='<img src="/BRT_web/live_status_sketch/images/dir_1.jpg" class="'+lcn+'02" title="BUS_id: '+inpudata.BRTID+'即將通過路口中 @Point '+inpudata.Point+'" width="20px" height="20px" style="position: absolute; left: '+ (x+10) +'px; top: '+ (y-45) +'px">';
                  $('.'+lcn+'02').remove();
                  domain_bus.append(str_img);
                  break;
               case 5:
                  str_img+='<img src="/BRT_web/live_status_sketch/images/dir_1.jpg" class="'+lcn+'02" title="BUS_id: '+inpudata.BRTID+'通過路口中 @Point '+inpudata.Point+'" width="20px" height="20px" style="position: absolute; left: '+ (x+0) +'px; top: '+ (y-45) +'px">';
                  $('.'+lcn+'02').remove();
                  domain_bus.append(str_img);
                  break;
               case 6:
                  str_img+='<img src="/BRT_web/live_status_sketch/images/dir_1.jpg" class="'+lcn+'02" title="BUS_id: '+inpudata.BRTID+'已通過路口 @Point '+inpudata.Point+'" width="20px" height="20px" style="position: absolute; left: '+ (x-10) +'px; top: '+ (y-45) +'px">';
                  $('.'+lcn+'02').remove();
                  domain_bus.append(str_img);
                  break;
               case 7:
                  $('.'+lcn+'02').remove();
                  break;
            }
         }
         if(inpudata.DIR !=1 && inpudata.DIR !=0){
            console.log('異常 -- DIR != 0 || 1 -- '+lcn);
         }
      }else{ // 8
         if(inpudata.Point ==8){
            console.log('異常 Point =8 -- 路口: '+lcn);
         }else{
            console.log('異常 Point !=8 -- 路口: '+lcn);
         }
      }
   }
}