/**
 * Created by Jia @ CCT on 2014/8/20.
 */
function RenewLight() {
   this.Initialize = Initialize;
   function Initialize(inputdata) {
   }
   this.set_connector = set_connector;
   function set_connector(web_socket) {
      this.connector = web_socket;
   }
   this.intersectionLight = intersectionLight;
   function intersectionLight(inputdata, cardData){
      lightProcess(inputdata, cardData);
   }

   function lightProcess(inputdata, cardData){
      if(inputdata[0].sub_phase == inputdata[1].sub_phase){
         var d0 = inputdata[0].card;
         var d1 = inputdata[1].card;
         if(cardData[d0-1].red !="0"){
            $('#circle'+cardData[0].equip_id).attr("fill", "#DC143C");
         }else{
            $('#circle'+cardData[0].equip_id).attr("fill", "#008000");
         }
      }

      }
}