/**
 * Created by hong on 2014/7/22.
 */

module.exports = {
    Initialize: function() {
    },
    get_data_tc: function() {
        return DataMakerTC();
    }
};

function DataMakerTC() {
    if (typeof DataMakerTC.countdown === "undefined") DataMakerTC.countdown = 15;
    if (typeof DataMakerTC.stepID === "undefined") DataMakerTC.stepID = 1;
    if (DataMakerTC.countdown < 0) {
        DataMakerTC.countdown = 15;
        DataMakerTC.stepID++;
    }
    if (DataMakerTC.stepID > 7) DataMakerTC.stepID = 1;
    var input_data = new Object();
    var result = [];
    var status = new Object();
    status.Strategy = 0;
    if (DataMakerTC.countdown  == 10) status.Strategy = 1;
    status.stepID = DataMakerTC.stepID;
    status.stepsec = DataMakerTC.countdown--;
    status.DIR = 0;
    status.LCN = 1234;
    status.BRTID = "love";
    status.PAtime = 1234;
    status.HOUR = 05;
    status.MIN = 00;
    status.SEC = 12;
    status.Point = 0;
    status.ONOff = 0;
    result[0] = status;
    input_data.FunctionNo = 3;
    input_data.MsgTypeNo = 1;
    input_data.immediate = new Object();
    input_data.immediate.result = result;
    return JSON.stringify(input_data);
}