/**
 * Created by hong on 2014/4/12.
 */

function MapDraw() {
    // Public member ----------------------------------------------------------
    this.Initialize = Initialize;
    function Initialize() {
        this.markers = [];
    }
    this.set_google_map = set_google_map;
    function set_google_map(google_map) {
        this.google_map = google_map;
    }
    this.set_location_data = set_location_data;
    function set_location_data(input_data) {
        this.data_reservoir = new DataReservoir();
        var data_reservoir = this.data_reservoir;
        data_reservoir.Initialize(input_data.intersection);
        data_reservoir.set_device_location(input_data);
    }
    this.Draw = Draw;
    function Draw() {
        var location_data = this.data_reservoir.Penstock();
//        console.log("reservoir_data: ", JSON.stringify(location_data));
        IconInfo(location_data, this.google_map, this.markers);
    }
    this.set_status_data = set_status_data;
    function set_status_data(input_data) {
        this.data_reservoir.set_device_status(input_data.status.information);
        var device_data = this.data_reservoir.Penstock();
        SetAllMap(null, this.markers);
        this.markers = [];
        IconInfo(device_data, this.google_map, this.markers);

    }
    // Private member ---------------------------------------------------------


//    this.IconInfo = IconInfo;
    function IconInfo(input_data, google_map, markers) {
        var type_set = ["tc", "dsrc", "gps", "ipc"];

        var current_type, current_data;
        for (var type_index = 0; type_index < type_set.length;++type_index) {
            current_type = type_set[type_index];
            current_data = input_data[current_type];
            for (var element_index = 0; element_index < current_data.length; ++element_index) {
                InfoWindows(current_type, current_data[element_index], markers);
            }
        }
        SetAllMap(google_map, markers);
    }
    this.Clear = Clear;
    function Clear(){
        this.SetAllMap(null, this.markers);
//       this.markers.length = 0;
    }
    function DrawIcon(google_map, lat_lng, multifunction) {
        var image_path = multifunction.get_image_path();

        var markers = [];
        PushImage(image_path, lat_lng, markers);
        SetAllMap(google_map, markers);


    }

    this.PushImage = PushImage;
    function PushImage(path, lat_lng, markers) {
        var marker = new google.maps.Marker({
            position: lat_lng,
            icon: {
                url: path
            }
        });
        markers.push(marker);
        google.maps.event.addListener(marker, 'rightclick', function() {
            marker.setMap(null);
        });
    }


    //
    function InfoWindows(current_type, input_data, markers) {
        var str_html="";
        var image_path, title;
        var is_connect = input_data.is_connect;
        switch(current_type) {
            case "tc":
                title = '號誌控制器';
                if (is_connect)
                    image_path = "device_manager/image/tc-connect.png";
                else
                    image_path = "device_manager/image/tc-disconnect.png";
                str_html += "<div style=\"width:120px;\">";
                str_html += "<p>設備編號: "+ input_data.intersection_id +" <\/p>";
                str_html += "<\/div>";
                break;
            case "dsrc":
                title = '短距離通訊';
                if (is_connect)
                    image_path = "device_manager/image/dsrc-connect.png";
                else
                    image_path = "device_manager/image/dsrc-disconnect.png";
                str_html += "<div style=\"width:120px;\">";
                str_html += "<p>設備編號: "+ input_data.intersection_id +" <\/p>";
                str_html += "<\/div>";
                break;
            case "gps":
                title = '衛星定位';
                if (is_connect)
                    image_path = "device_manager/image/gps-connect.png";
                else
                    image_path = "device_manager/image/gps-disconnect.png";
                str_html += "<div style=\"width:120px;\">";
                str_html += " "+ input_data.intersection_id +" <\/p>";
                str_html += "<\/div>";
                break;
            case "ipc":
                title = '電腦';
                if (is_connect)
                    image_path = "device_manager/image/ipc-connect.png";
                else
                    image_path = "device_manager/image/ipc-disconnect.png";
                str_html += "<div style=\"width:120px;\">";
                str_html += "<p>設備編號: "+ input_data.intersection_id +" <\/p>";
                str_html += "<\/div>";
                break;

        }
        var lat_lng = new google.maps.LatLng(input_data.latitude, input_data.longitude);
        var infowindow = new google.maps.InfoWindow({
            content: str_html,
            width: 50
        });
        var marker = new google.maps.Marker({
            position: lat_lng,
            icon: {
                url: image_path
            },
            title: title
        });
        google.maps.event.addListener(marker, 'click', function() {
            infowindow.open(map,marker);
        });
//        google.maps.event.addListener(marker, 'rightclick', function() {
//            console.log("delete " + input_data.id);
//            var delete_data = new Object();
//            delete_data.id = input_data.id;
//            var json_data = {};
//            json_data.FunctionNo = 601;
//            json_data.MsgTypeNo = 3;
//            json_data.active = "delete";
//            json_data.accident = delete_data;
//            web_socket_manager.Send(json_data);
//            marker.setMap(null);
//        });
        markers.push(marker);

    }
    this.SetAllMap = SetAllMap;
    function SetAllMap(map, markers) {
        for (var i = 0; i < markers.length; i++) {
            markers[i].setMap(map);
        }
    }


}
