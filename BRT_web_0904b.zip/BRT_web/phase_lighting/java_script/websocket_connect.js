/**
 * Created by Jia on 2014/7/15.
 */
function PhaseLightingWebSocket() {
   // Public member ----------------------------------------------------------
   this.Initialize = Initialize;
   function Initialize() {
      this.web_socket = new WebSocket('ws://192.168.1.2:9098');
//      this.web_socket = new WebSocket('ws://192.168.1.186:9000', "echo");
   }
   this.Connect = Connect;
   function Connect() {
      this.ConnectToServer(this, this.web_socket);
   }
   this.Send = Send;
   function Send(json_data){
      var json_string = JSON.stringify(json_data);
      console.log("Send :"+ json_string);
      this.web_socket.send(json_string);
   }
   this.Reload = Reload;
   function Reload() {

   }

   this.ConnectToServer = ConnectToServer;
   function ConnectToServer(web_socket_manager, web_socket) {
      console.log("web socket");
      web_socket.onopen = function () {
         console.log("web socket open");
//         RequestIntersection();
         var phasenno = '01';
         RequestPhaseinitial(web_socket, phasenno);
      };
      web_socket.onerror = function () {
         console.log("web socket error!");
      };
      web_socket.onmessage = function (message) {
//      console.log(message.data);
         var data = JSON.parse(message.data);
         DataAssign(data, web_socket_manager);
      };
   }

   function RequestPhaseinitial(web_socket, phasenno) {
      var json_data = new Object();
      json_data.FunctionNo =203;
      json_data.MsgTypeNo =4;
      json_data.phase_no =phasenno;
      var json = JSON.stringify(json_data);
      web_socket.send(json);
   }





   function DataAssign(input_data, web_socket) {
      var label = input_data.FunctionNo.toString() + "-" + input_data.MsgTypeNo.toString();
      switch(label){
         case '203-3':
            console.log("receive : 203-3");
            console.log(JSON.stringify(input_data));
            var sett = new setTable();
            sett.Initialize();
            sett.set_web_socket(web_socket);
            sett.Insert(input_data.phasedata);
            var intter =new eventListen();
            intter.Initialize();
            intter.set_web_socket(web_socket);
            intter.Updata(web_socket, input_data);
            break;
         case '203-5':
            console.log("receive : 203-5");
            console.log(JSON.stringify(input_data));
            var intersection =new eventListen();
            intersection.Initialize();
            intersection.set_web_socket(web_socket);
            intersection.Insert(input_data.phase);
            intersection.Listen();
            break;
         case '203-7':
            console.log("receive : 203-7 update DB SUCCESS");
            var status = new returnStatus();
            status.Initialize();
            status.updateDB();
            break;
         default:
            console.log("Data not be assigned.");
            break;
      }
   }
}

