/**
 * Created by CCT on 2014/8/26.
 */
function returnStatus() {
   this.Initialize = Initialize;
   function Initialize() {
   }
   this.updateDB = updateDB;
   function updateDB(){
      update_DB_status();
   }
   this.updateTC = updateTC;
   function updateTC(){
      update_TC_status();
   }
   function update_DB_status(){
      var success_info =$('.status').empty();
      var str_alert ="";
      str_alert +='<div class="alert alert-info" role="alert"><strong>已成功更新資料庫</strong></div>';
      success_info.append(str_alert);
   }
   function update_TC_status(){

   }
}