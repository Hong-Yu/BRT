/**
 * Created by Jia on 2014/10/6.
 */
function RouteWebSocket() {
   // Public member ----------------------------------------------------------
   this.Initialize = Initialize;
   function Initialize() {
      this.web_socket = new WebSocket('ws://192.168.1.2:9098');
   }
   this.Connect = Connect;
   function Connect() {
      this.ConnectToServer(this, this.web_socket);
   }
   this.Send = Send;
   function Send(data){
      var json_data = JSON.stringify(data);
      this.web_socket.send(json_data);
   }
   this.Reload = Reload;
   function Reload() {
//      RequestRouteData(this.web_socket);
   }
   // Private member ---------------------------------------------------------
   this.ConnectToServer = ConnectToServer;
   function ConnectToServer(web_socket_manager, web_socket) {
      console.log("web socket");

      web_socket.onopen = function () {
         console.log("web socket open");
      };
      web_socket.onerror = function () {
         console.log("web socket error!");
      };
      web_socket.onmessage = function (message) {
         var data = JSON.parse(message.data);
         DataAssign(data, web_socket_manager);
      };
   }

   function DataAssign(input_data, web_socket_manager) {
      var label = input_data.FunctionNo.toString() + "-" + input_data.MsgTypeNo.toString();
      switch(label){
         case '400-2':
            console.log("receive 400-2");
            var routeDraw = new SketchMap();
            routeDraw.SketchInitial();
            routeDraw.set_web_socket(web_socket_manager);
            routeDraw.DrawMap(input_data);
            var event = new EventManager();
            event.set_web_socket(web_socket_manager);
            event.listenTab();
             break;
         default:
            console.log("Data not be assigned. @live_steps");
            break;
      }
   }
}
