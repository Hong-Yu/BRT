/**
 * Created by hong on 2014/4/17.
 * Modified by Jia on 2014/7/20.
 * Listen Click_Event of Route_Map_SVG And show Intersection Info.
 */

function EventManager() {
this.Initial = Initial;
function Initial(input_data){
}
this.set_web_socket = set_web_socket;
function set_web_socket(ws) {
   this.web_socket = ws;
}
this.listenTab = listenTab;
function listenTab(){
   nav_change();
}
this.ListenMap = ListenMap;
function ListenMap(input_data){
   TextListen(input_data);
}

   function nav_change(){
      var nav_0 = $('#dir0');
      var nav_1 = $('#dir1');
      var check = $('#check');
      var domain_bus =$('div.divmap');
      nav_1.click(function(){
         nav_0.removeAttr('class');
         nav_1.attr('class', 'active');
         check.attr('mark', '1');
         domain_bus.empty();
      });
      nav_0.click(function(){
         nav_1.removeAttr('class');
         nav_0.attr('class', 'active');
         check.attr('mark', '0');
         domain_bus.empty();
      });
   }

   function TextListen(inputdata){
      var domain_t = $('svg g text');
      domain_t.hover(
         function(){
            $(this).css({"cursor":"pointer", "fill": "SeaGreen"});
         },
         function(){
            $(this).css({"fill":"black"});
         });

      domain_t.click(function(){
         var x = $(this).offset().left;
         var y = $(this).offset().top;
         var locationId = $(this).attr('id');
         var locarionName = this.innerHTML;
         InsertInfo(locationId, locarionName, x, y,inputdata);
      });
   }

   function InsertInfo(locationId, locarionName, x, y, inputdata){
      var domain_info = $('div.divinfo');
      domain_info.empty();
      var name = locarionName;
      var num = locationId;
      var str_table="";
      str_table +='<div class="panel panel-default" style="width: 330px; position: absolute; left: '+(x+50)+'px; top: '+(y+20)+'px">';
      str_table +='<div class="panel-body">';
      str_table +='<button type="button" class="close glyphicon glyphicon-remove" data-dismiss="alert"></button>';
      str_table +='<img src="/BRT_web/intersection_imgs/'+num+'.gif" title="'+name+' 路口簡圖">';
      str_table +='<div><h4>'+num+' '+name+'</h4><p>';
      str_table +='<table class="table table-striped table-bordered" style="text-align:center;">';
      str_table +='<thead><tr><th>方向</th><th>往靜宜</th><th>往火車站</th></tr></thead>　<tbody><tr><td>優先狀態</td><td class="status" colspan="2">---</td></tr>';
      str_table +='<tr><td>優先策略</td><td class="strategy0">---</td><td class="strategy1">---</td></tr></tbody></table></p></div></div></div>';

      domain_info.append(str_table);
      if(inputdata.LCN ==parseInt(locationId)){
         InsertTable(inputdata);
      }
   }

   function InsertTable(input_data){
      var text_condition = "未有資料";
      switch (input_data.Condition){
         case 0:
            text_condition = "手動關機";
            break;
         case 1:
            text_condition = "定時關機";
            break;
         case 2:
            text_condition = "手動優先控制執行中";
            break;
         case 3:
            text_condition = "定時優先控制執行中";
            break;
         case 4:
            text_condition = "手動待機";
            break;
         case 5:
            text_condition = "定時待機";
            break;
         default:
            text_condition = "未有資料";
            break;
      }
      var status = $('td.status').text(text_condition);

      var text_status="未有資料";
      var text_status2="未有資料";
      if(input_data.DIR ==0){
         switch (input_data.Strategy){
            case 0:
               text_status = "無";
               break;
            case 1:
               text_status = "延長綠燈";
               break;
            case 2:
               text_status = "切斷紅燈";
               break;
            default:
               text_status = "未有資料";
               break;
         }
         var strategy0 = $('td.strategy0');
         strategy0.empty();
         strategy0.text(text_status);
      }if(input_data.DIR ==1){
         switch (input_data.Strategy){
            case 0:
               text_status2 = "無";
               break;
            case 1:
               text_status2 = "延長綠燈";
               break;
            case 2:
               text_status2 = "切斷紅燈";
               break;
            default:
               text_status2 = "未有資料";
               break;
         }
         var strategy1 = $('td.strategy1');
         strategy1.empty();
         strategy1.text(text_status2);
      }else{
         console.log('DIR Error -- event_manager.js');
      }
   }
}