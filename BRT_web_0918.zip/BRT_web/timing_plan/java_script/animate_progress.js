/**
 * Created by CCT on 2014/5/21.
 */
function AnimateProgressBar() {
   this.Reset = Reset;
   function Reset(message_max) {
      this.message_max = message_max;
      this.row_index = 0;
      this.progress_bar = $('#centerview').find("div.progress-bar-info");
   }
   this.Touch = Touch;
   function Touch() {
      console.log(this.message_max + "  " + this.row_index);
      this.row_index++;
      var percentage = this.row_index/this.message_max * 100 + "%";
      console.log(percentage);
      $(this.progress_bar).animate({
         width: percentage
      },100);
   }
//   var progress_bar = $('#centerview').find("div.progress-bar-info");
//   $(progress_bar).animate({
//      width:'100%'
//   },3000);
//   CommunicateInformation();
//   var progress = progress_bar.attr("aria-valuenow");
//   console.log(progress);
}
