/**
 * Created by CCT on 2014/8/26.
 */
function returnStatus() {
   this.Initialize = Initialize;
   function Initialize() {
   }
   this.downStatus = downStatus;
   function downStatus(inputdata){
      success_fail(inputdata);
   }
   function success_fail(inputdata){
      var status_info =$('.status');
       var str_control="";
       switch (inputdata.CommandID){
           case 'BF11':
               str_control+="優先號誌";
               break;
           case '5014':
               str_control+="行人倒數";
               break;
           case '5015':
               str_control+="行車倒數";
               break;
           case '0F10':
               str_control+="重啟設備";
               break;
           case '0F15':
               str_control+="設備密碼";
               break;
           case '0F12':
               str_control+="設備日期時間";
               break;
           case '0F92':
               str_control+="設備日期時間";
               break;
           case '0F14':
               str_control+="設備周期";
               break;
           default :
               str_control+=inputdata.CommandID;
               break;
       }
       if(inputdata.key == '0F80'){
           var str_alert ="";
           str_alert +='<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert">' +
               '<span aria-hidden="true">&times;</span><span class="sr-only"></span></button><strong>設定 '+str_control+' 至路口 '+inputdata.LCN+' 已成功!</strong></div>';
           status_info.append(str_alert);
       }if(inputdata.key == '0F81'){
           var str_alert ="";
           str_alert +='<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert">' +
               '<span aria-hidden="true">&times;</span><span class="sr-only"></span></button><strong>設定 '+str_control+' 至路口 '+inputdata.LCN+' 失敗!</strong></div>';
           status_info.append(str_alert);
       }
   }
}