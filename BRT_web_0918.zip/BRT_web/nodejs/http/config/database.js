// Microsoft SQL server
var mssql = require('../lib/mssql_connector');
mssql.Initialize();
var ms_connector = mssql.get_connector();
// sql smart generator
var sql_generator =  require('../lib/sql_generator.js');
// phase modify
var phase_modigy = require('./phase_modify.js');
phase_modigy.Initialize(ms_connector, sql_generator);
// intersection request
var intersection = require('./Intersection_request');
intersection.Initialize(ms_connector, sql_generator);
// config/database.js
module.exports = {
    AccountExist : function(input_data, response) {
        ValidAccount(input_data, response);
    },
   SignUp : function(input_data, response) {
      SignUp(input_data, response);
   },
   AccountList : function(input_data, response) {
      AccountList(input_data, response);
   },
   AccountDelete : function(input_data, response) {
      AccountDelete(input_data, response);
   },
    PhaseList : function(input_data, response) {
        phase_modigy.PhaseList(response);
    },
    PhaseUpdate :function(input_data, response) {
        phase_modigy.PhaseUpdate(input_data.phase, response);
    },
   PhaseDelete : function(input_data, response){
      phase_modigy.PhaseDelete(input_data.phase_no, response);
   },
   PhaseRenew : function(input_data, response){
      phase_modigy.PhaseRenew(input_data.phase_data, response);
   },
   PhaseRenewStep : function(input_data, response){
      phase_modigy.PhaseRenewStep(input_data.phase_data, response);
   },
    IntersectionList : function(input_data, response){
        intersection.List(response);
    }
}

function ValidAccount(input_data, response) {
    // 1. Select user account
    var table_name = "user_account";
    var column_name = ["email", "password"];
    var column_type = [0, 0];
    var cmd_sql = "";
    cmd_sql += "SELECT ID, level FROM " + table_name + " ";
    cmd_sql += sql_generator.Where(column_name, column_type, input_data);
    cmd_sql += sql_generator.End();
//    cmd_sql += "WHERE email =" + input_data.email + " AND password =" + input_data.password + ";";
    console.log(cmd_sql);
    ExecuteWithResult(ms_connector, response, "user_account");
    function ExecuteWithResult(connector, response, mark) {
        var query = connector.query(cmd_sql);
        query.exec( function( err, res ){
            if(err){
                console.log('select error: ', mark);
                console.log(err);
                return;
            }else{
                console.log(res);
                var isAuthenticated = false;
                if (res.rowcount == 1) isAuthenticated = true;
                response.json({ isAuthenticated: isAuthenticated, account:res.result[0] });
            }
        });
    }
}

function SignUp(input_data, response) {
   var table_name = "user_account";
   var column_name = ["email", "password", "level"];
   var column_type = [0, 0, 1];
   var cmd_sql = "";
   cmd_sql += sql_generator.InsertInto(table_name, column_name, column_type, input_data);
   cmd_sql += sql_generator.End();
   console.log(cmd_sql);
   var success = new Successful();
   success.set_response(response);
   var fail = new Fail();
   fail.set_response(fail);
   sql_generator.ExecuteWith("Insert user account ", ms_connector, cmd_sql, success, fail);
   function Successful() {
      this.set_response =set_response;
      function set_response(response) {
         this.response = response;
      }
      this.set_result = set_result;
      function set_result(result) {
         this.result = result;
      }
      this.Response = Response;
      function Response() {
         response.json({ successful: true, message: "Insert successful" });
      }
   }
   function Fail() {
      this.set_response = set_response;
      function set_response(response) {
         this.response = response;
      }
      this.set_error = set_error;
      function set_error(error) {
         this.error = error;
      }
      this.Response = Response;
      function Response() {
         response.json({ successful: false, message: this.error.message });
      }
   }
}

function AccountList(input_data, response) {
   var table_name = "user_account";
   var cmd_sql = "";
   cmd_sql += "SELECT * FROM " + table_name + " ";
   var success = new Successful();
   success.set_response(response);
   var fail = new Fail();
   fail.set_response(fail);
   sql_generator.ExecuteWith("select user account ", ms_connector, cmd_sql, success, fail);
   function Successful() {
      this.set_response =set_response;
      function set_response(response) {
         this.response = response;
      }
      this.set_result = set_result;
      function set_result(result) {
         this.result = result;
      }
      this.Response = Response;
      function Response() {
         response.json({ successful: true, accounts: this.result.result });
      }
   }
   function Fail() {
      this.set_response = set_response;
      function set_response(response) {
         this.response = response;
      }
      this.set_error = set_error;
      function set_error(error) {
         this.error = error;
      }
      this.Response = Response;
      function Response() {
         response.json({ successful: false, message: this.error.message });
      }
   }
}

function AccountDelete(input_data, response) {
   //    Delete: function(table_name) {
   //     Where: function(primary_key, primary_type, input_data) {
   var table_name = "user_account";
   var column_name = ["email"];
   var column_type = [0];
   var cmd_sql = "";
   cmd_sql += sql_generator.Delete(table_name);
   cmd_sql += sql_generator.Where(column_name, column_type, input_data);
   cmd_sql += sql_generator.End();
   console.log(cmd_sql);
   sql_generator.Execute("select user account ", ms_connector, cmd_sql);






}