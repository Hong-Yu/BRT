/**
 * Created by hong on 2014/4/12.
 */

function MapDraw() {
    // Public member ----------------------------------------------------------
    this.Initialize = Initialize;
    function Initialize() {
       this.polylines = [];
    }
   this.set_google_map = set_google_map;
   function set_google_map(google_map) {
      this.google_map = google_map;
   }
   this.set_route_info = set_route_info;
   function set_route_info(route_info) {
      this.route_info = route_info;
   }
    this.BusStation=BusStation;
    function BusStation(input_data) {
        this.markers = [];
        for (var int_index = 0; int_index < input_data.length; int_index++) {
            var current_data = input_data[int_index];
            var lat = current_data.latitude;
            var lng = current_data.longitude;
            var lat_lng = new google.maps.LatLng(lat, lng);
            this.PushImage("brt_performance/image/bus_station.png", lat_lng, this.markers);

        }
        this.SetAllMap(this.google_map, this.markers);
    }
    this.RouteSection=RouteSection;
    function RouteSection(input_data) {
       this.SetAllMap(null, this.polylines);
       this.polylines = [];
        for (var section_index = 0; section_index < input_data.length; section_index++) {
            var current_data = input_data[section_index];
            var lat_begin = current_data.begin_lat;
            var lng_begin = current_data.begin_lng;
            var lat_end = current_data.end_lat;
            var lng_end = current_data.end_lng;
            var congestion = current_data.congestion;
            var color;
            switch(congestion){
                case 0:
                    color = "#009933";
                    break;
                case 1:
                    color = "#FF0000";
                    break;
                case 2:
                    color = "#FF9900";
                    break;
            }
            // #009933 #FF0000 #FF9900
            this.PushPolyLine(lat_begin, lng_begin, lat_end, lng_end, color, section_index, this.route_info,  this.polylines)

        }
        this.SetAllMap(this.google_map, this.polylines);
    }

    this.Icon = Icon;
    function Icon(lat_lng) {
        this.markers = [];
        this.PushImage("accident/image/accident.png", lat_lng, this.markers);
        this.SetAllMap(this.google_map, this.markers);
    }
    this.Icons = Icons;
    function Icons(web_socket_manager, input_data) {
        this.markers = [];
        for (var icon_index = 0; icon_index < input_data.length; icon_index++) {
            var current_data = input_data[icon_index];
            var lat_lng = new google.maps.LatLng(current_data.latitude, current_data.longitude);
            console.log(lat_lng);
//            this.PushImage("accident/image/accident.png", lat_lng, this.markers);
            InfoWindows(web_socket_manager, this.google_map,  lat_lng, current_data, this.markers);
        }
        this.SetAllMap(this.google_map, this.markers);
//        this.InfoWindows(this.google_map, this.markers);

    }
    this.Clear = Clear;
    function Clear(){
        this.SetAllMap(null, this.markers);
//       this.markers.length = 0;
    }
    // Private member ---------------------------------------------------------
    this.BindCreateAccidentEvent = BindCreateAccidentEvent;
    function BindCreateAccidentEvent(lat_lng) {

    }
    this.PushImage = PushImage;
    function PushImage(path, lat_lng, markers) {
        var marker = new google.maps.Marker({
            position: lat_lng,
            icon: {
                url: path
            }
        });
        markers.push(marker);
    }
    // poly line
    this.PushPolyLine = PushPolyLine;
    function PushPolyLine(lat_begin, lng_begin, lat_end, lng_end, color, section_index, route_info, polylines) {
        var flightPlanCoordinates = [
            new google.maps.LatLng(lat_begin, lng_begin),
            new google.maps.LatLng(lat_end, lng_end),
        ];
        var flightPath = new google.maps.Polyline({
            path: flightPlanCoordinates,
            geodesic: true,
            strokeColor: color,
            strokeOpacity: 1.0,
            strokeWeight: 10
        });
        polylines.push(flightPath);
        google.maps.event.addListener(flightPath, 'click', function() {
            console.log("click");

           route_info.ShowTable(section_index);
           route_info.PaintSketchMap(section_index);
           $("div.route_sketch").show();
        });
//        flightPath.setMap(map);
    }

    //
    this.InfoWindows = InfoWindows;
    function InfoWindows(web_socket_manager, map, lat_lng, input_data, markers) {
        var str_html="";
        str_html += "<div style=\"width:120px;\">";
        str_html += "<p>車牌:"+ input_data.license_plate +" <\/p>";
        str_html += "<p>描述: "+ input_data.statement +"<\/p>";
        str_html += "<\/div>";
        var infowindow = new google.maps.InfoWindow({
            content: str_html,
            width: 50
        });
        var marker = new google.maps.Marker({
            position: lat_lng,
            icon: {
                url: "accident/image/accident.png"
            },
            title: '意外事故'
        });
        google.maps.event.addListener(marker, 'click', function() {
            infowindow.open(map,marker);
        });
        google.maps.event.addListener(marker, 'rightclick', function() {
            console.log("delete " + input_data.id);
            var delete_data = new Object();
            delete_data.id = input_data.id;
            var json_data = {};
            json_data.FunctionNo = 201;
            json_data.MsgTypeNo = 3;
            json_data.active = "delete";
            json_data.accident = delete_data;
            web_socket_manager.Send(json_data);
            marker.setMap(null);
        });
        markers.push(marker);

    }
    this.SetAllMap = SetAllMap;
    function SetAllMap(map, markers) {
        for (var i = 0; i < markers.length; i++) {
            markers[i].setMap(map);
        }
    }


}
