/**
 * Created by CCT on 2014/2/19.
 */
function UploadAction() {
   // Public member ----------------------------------------------------------
   // temp routine until segment manager finish.
   this.set_segment_type_conjunct = set_segment_type_conjunct;
   function set_segment_type_conjunct(segment_type_conjunct) {
      this.segment_type_conjunct = segment_type_conjunct;
   }
   this.set_websocket = set_websocket;
   function set_websocket(web_socket) {
      this.web_socket = web_socket;
   }
   this.Listen = Listen;
   function Listen() {
      ListenUploadButton(this.web_socket, this.segment_type_conjunct);
   }
   // Private member ---------------------------------------------------------
   function ListenUploadButton(web_socket, segment_type_conjunct) {
      console.log("Upload listener ready.");
      var domain_button = $("button.timing_plan_upload");
      domain_button.click(function(){
         console.log("Upload -------------------------------------------------- !");
         var upload_data = new TimingPlanUploadTransfer();
         upload_data.set_segment_type_conjunct(segment_type_conjunct);
         var json_data = upload_data.Package();
         SentTo(json_data, web_socket);
         // Disable button to prevent user multiple clicks.
         domain_button.attr('disabled', 'disabled');
         Waiting(10);
         function Waiting(interval) {
            if (typeof Waiting.timer === 'undefined') {
               Waiting.timer = interval;
            } else if (Waiting.timer <= 0) {
               domain_button.removeAttr('disabled');
               domain_button.text("資料傳輸");
               Waiting.timer = interval;

               return;
            }
            domain_button.text("傳輸中請稍後 .. ("+ Waiting.timer +")");
            Waiting.timer--;
            setTimeout(arguments.callee, 1000);

         }

      });
   }

   function SentTo(json, web_socket) {
      web_socket.Send(json);
   }



//   function AnimateProgressBar() {
//      var progress_bar = $('#centerview').find("div.progress-bar-info");
//      $(progress_bar).animate({
//         width:'100%'
//      },3000);
//      CommunicateInformation();
//      var progress = progress_bar.attr("aria-valuenow");
//      console.log(progress);
//   }
//
//   var line_index = 0;
//   function CommunicateInformation() {
//      if (line_index >= 7) return;
//      var text_area = $('#centerview').find("select.form-control");
//      text_area.find("option").removeAttr( "selected" );
//      var text_comm = "<option selected='selected'>" + line_index + "  AABB ... AACC</option>";
//      text_area.append(text_comm);
//      ++line_index;
//      $('select.form-control').scrollTop((line_index - 3) * 20);
//      setTimeout(arguments.callee, 500);
//   }
//
//   function getNow(){
//      var d = new Date();
//      var month = d.getMonth()+1;
//      var day = d.getDate();
//      var hours = d.getHours();
//      var minutes = d.getMinutes();
//      var seconds = d.getSeconds();
//      var output = '"'+d.getFullYear()+'-'+(month<10 ? '0' : '')+month+'-'+(day<10 ? '0' : '')+day+" "+(hours<10 ? '0' : '')+hours+":"+(minutes<10 ? '0' : '')+minutes+":"+(seconds<10 ? '0' : '')+seconds+'"';
//      return output;
//   }

}







