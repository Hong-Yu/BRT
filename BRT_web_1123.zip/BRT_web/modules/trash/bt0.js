// 登入
var bt0=function(){
	var UIs=$('\
		<hr style="margin:5px;vertical-align:middle;border: 1px solid #DDDDDD;" />\
		\
		<div class="accordion-group">\
			<div class="accordion-heading">\
				<div style="color:gold;" class="accordion-toggle btn btn-primary text-center" data-toggle="collapse" data-parent="#accordion2" href="#collapse5" onclick="bt9();">\
					歷史資料查詢\
				</div>\
			</div>\
		</div>\
		\
		<div class="accordion-group">\
			<div class="accordion-heading">\
				<div style="color:gold;" class="accordion-toggle btn btn-primary text-center" data-toggle="collapse" data-parent="#accordion2" href="#collapse5" onclick="bt10();">\
					系統帳號管理\
				</div>\
			</div>\
		</div>\
		\
		<div class="accordion-group">\
			<div class="accordion-heading">\
				<div style="color:gold;" class="accordion-toggle btn btn-primary text-center" data-toggle="collapse" data-parent="#accordion2" href="#collapse5" onclick="sub_page_device_manager();">\
					路口設備管理\
				</div>\
			</div>\
		</div>\
       \
		<div class="accordion-group">\
			<div class="accordion-heading">\
				<div style="color:gold;" class="accordion-toggle btn btn-primary text-center" data-toggle="collapse" data-parent="#accordion2" href="#collapse5" onclick="sub_page_route_manager();">\
					路線管理\
				</div>\
			</div>\
		</div>\
	');
//sub_page_route_manager


};