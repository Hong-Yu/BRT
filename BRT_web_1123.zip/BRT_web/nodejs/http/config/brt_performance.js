/**
 * Created by Administrator on 2014/9/17.
 */
module.exports = {
    Initialize : function(ms_connector, sql_generator) {
        this.ms_connector = ms_connector;
        this.sql_generator = sql_generator;
    },
    DataProcess : function(input_data, response) {
        // send data to DB and renew
        console.log(input_data);
    }
};