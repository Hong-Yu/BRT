/**
 * Created by hong on 2014/5/13.
 */
function LoginSystem() {
    // Public member ----------------------------------------------------------
    this.Initialize = Initialize;
    function Initialize() {
        this.LoginButton();
        this.LoginConfirm();
//        LoginStart();

    }
    // Private member ----------------------------------------------------------
    this.LoginButton = LoginButton;
    function LoginButton() {
        var domain = $("div.login_button");
        domain.attr("data-target", "#user_login");
        domain.attr("data-toggle", "modal");
        console.log(domain);
        domain.bind("click", ButtonClick);
        function ButtonClick() {
            console.log("click");
            var type = $("div.login_button").text();
            if (type == "登入") {
                console.log(type);
            } else {
                document.location.reload(true);
            }
        }
    }
    this.LoginConfirm = LoginConfirm;
    function LoginConfirm() {
        var domain = $("#user_login");
        var domain_login = $("button.login");
//        domain_login.bind("click", ClickLogin);
//        ClickLogin();
        function ClickLogin() {
            $('#user_login').modal('show');

            var post_data = new Object;
            post_data.email = domain.find("input[type=email]").val();
            post_data.password = domain.find("input[type=password]").val();
            $.post( "http://192.168.1.2:8888/test-page", post_data )
                .done(function( data ) {
                    console.log(data);
                    if(data.isAuthenticated)
                        Success(data.account.level);
                    else
                        Error();
                });

        }
        function Error() {
            domain.find("div.authenticated_error").show();
        }
        function Success(level) {
            domain.modal('hide');
            $("div.login_button").text("登出");
            $("div.login_button").attr("data-toggle", "");

            $("div.login_button").removeClass('login_button').addClass('sign_out_button');
            $.get("user_system/sub_page/managed_function.html",function(data){
                $('div.dashboard').append(data);
                if(level == 10)
                    $("div.account_manager").show();
            });
        }
    }
    function LoginStart() {

    }

}
