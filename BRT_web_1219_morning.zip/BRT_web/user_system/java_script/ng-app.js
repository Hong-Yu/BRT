/**
 * Created by hong on 2014/11/11.
 */
(function(){ // anonymous self-invoking function
    var app = angular.module('home.page.app', ['http.service']);

    app.controller('HomePageController', ['$scope', 'httpService', function($scope, http_service) {
        $scope.http_service = http_service;
        $scope.user_data = {};
        $scope.user_data.email = null;
        $scope.user_data.password = null;
        $scope.permission_data = {};
        $scope.value = 1;

        $scope.SignIn = function() {
            var promise  = http_service.SignIn($scope.user_data);
            promise.then(function(data) {
                $scope.permission_data = data.data.result[0];
                console.log("permission data A: ", $scope.permission_data);
                $scope.value = 100;
            }, function(reason) {});
        };
        $scope.Permission = function(function_name) {
            return $scope.permission_data[function_name];
        };
        $scope.isDeveloper = function() {
            return $scope.permission_data.level == 100;
        };
        $scope.SignOut = function() {
            $scope.user_data = {};
            http_service.sign_in_successful = null;
            http_service.sign_in_error = false;
            var div = document.getElementById('centerview');
            while(div.firstChild){
                div.removeChild(div.firstChild);
            }
        };
    }]);



    app.directive("mainCanvas", function(){
        console.log("main page append !");
        return{
            restrict: 'E',
            templateUrl:'user_system/sub_page/home_page.html'
        }
    });
})();