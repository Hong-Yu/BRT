/**
 * Created by hong on 2014/10/27.
 */


angular.module('ui.bootstrap.app').factory('HttpService', ['$scope', '$http', '$templateCache',
    function($scope, $http, $templateCache) {
        var service = {};

        $scope.method = 'GET';
        $scope.url = 'http-hello.html';

        $scope.fetch = function() {
            $scope.code = null;
            $scope.response = null;

            $http({method: $scope.method, url: $scope.url, params: {act:'add'}, data: $scope.data, cache: $templateCache}).
                success(function(data, status) {
                    $scope.status = status;
                    $scope.data = data;
                    console.log("response -- status: ", status, " data: ", data);
                }).
                error(function(data, status) {
                    $scope.data = data || "Request failed";
                    $scope.status = status;
                    console.log("response -- status: ", status, " data: ", data);

                });
        };

        $scope.updateModel = function(method, url, data) {
            $scope.method = method;
            $scope.url = url;
            $scope.data = data;
            console.log($scope);
            $scope.fetch();
        };
        return service;
    }]);