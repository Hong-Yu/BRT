/**
 * Created by hong on 2014/10/27.
 */

var modalApp = angular.module('ui.bootstrap.app', ['ui.bootstrap']);
modalApp.controller('ModalDemoCtrl', [ '$scope', '$modal', '$log',  function ( $scope, $modal, $log) {

    $scope.items = ['item1', 'item2', 'item3', 'item99'];

    $scope.open = function (size) {

        var modalInstance = $modal.open({
            templateUrl: 'myModalContent.html',
            controller: 'ModalInstanceCtrl',
            size: size,
            resolve: {
                items: function () {
                    return $scope.items;
                }
            }
        });

        modalInstance.result.then(function (selectedItem) {
            $scope.selected = selectedItem;
        }, function () {
            $log.info('Modal dismissed at: ' + new Date());
        });
    };
}]);

// Please note that $modalInstance represents a modal window (instance) dependency.
// It is not the same as the $modal service used above.

modalApp.controller('ModalInstanceCtrl', function ($scope, $modalInstance, $http, $templateCache, items) {

    $scope.items = items;
    $scope.selected = {
        item: $scope.items[0]
    };
    $scope.review = {name:'', color:'', intersection_max:null};

    $scope.ok = function () {
        $modalInstance.close($scope.selected.item);
        $http({method: 'POST', url: 'http://192.168.1.2:8888/route-manager', params: {act:'routes-add'}, data: $scope.review, cache: $templateCache}).
            success(function(data, status) {
//                $scope.status = status;
//                $scope.routes = data.data.result;
                console.log("response -- status: ", status, " data: ", data);
            }).
            error(function(data, status) {
//                $scope.data = data || "Request failed";
//                $scope.status = status;
                console.log("response -- status: ", status, " data: ", data);

            });
//        updateModel('POST', 'http://192.168.1.2:8888/route-manager', review)
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
});

// Append
modalApp.directive("modalDynamic", function($compile){
//    console.log("dynamic: ");
    return{
        link: function(scope, element){
            $.get("route_manager/sub_page/modal_route_add.html", function(data) {
                var template = data;
                var linkFn = $compile(template);
                var content = linkFn(scope);
                element.append(content);
            });
        }
    }
});

