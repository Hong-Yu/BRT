/**
 * Created by hong on 2014/4/11.
 */

function PerformanceMain() {
   var domain_main;
   domain_main=$('#centerview').empty().css('background-color','transparent');
   $.get("brt_performance/sub_page/main.html", function(data) {
      domain_main.prepend(data);

      PrimaryDataProcess();
   });

   function PrimaryDataProcess() {
      // prepare map manager function to set google map on our website.
      var map_manager = new MapManager();
      var google_map = map_manager.Initialize();
      map_manager.Legend();
      // Draw map function have many tool to draw something on our map.
      var map_draw = new MapDraw();
      map_draw.Initialize();
      map_draw.set_google_map(google_map);
      // Connect to NodeJs server
      var web_socket = new RouteWebSocket();
      web_socket.Initialize();
      web_socket.set_map_manager(map_manager);
      web_socket.set_map_draw(map_draw);
      web_socket.Connect();

   }

}
