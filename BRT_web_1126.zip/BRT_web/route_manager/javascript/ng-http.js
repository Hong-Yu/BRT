/**
 * Created by hong on 2014/10/27.
 */
(function(){ // anonymous self-invoking function
    var app = angular.module('http-service', []);

    app.factory('httpFactory', ['$http', '$templateCache',
        function( $http, $templateCache) {
            var service = {};
//            service.message = 'AKB48';
//
//            $scope.method = 'GET';
//            $scope.url = 'http-hello.html';

            service.fetch = function(method, url, data) {
                service.code = null;
                service.response = null;

                $http({method: method, url: url, params: {act:'add'}, data: data, cache: $templateCache}).
                    success(function(data, status) {
                        service.status = status;
                        service.data = data;
                        console.log("response -- status: ", status, " data: ", data);
                    }).
                    error(function(data, status) {
                        service.data = data || "Request failed";
                        service.status = status;
                        console.log("response -- status: ", status, " data: ", data);

                    });
            };

//            $scope.updateModel = function(method, url, data) {
//                $scope.method = method;
//                $scope.url = url;
//                $scope.data = data;
//                console.log($scope);
//                $scope.fetch();
//            };
            return service;
        }]);
})();


