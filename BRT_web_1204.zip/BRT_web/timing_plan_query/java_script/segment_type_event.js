/**
 * Created by hong on 2014/3/3.
 */
var segment_type_listener = new Object();
function SegmentTypeEvent() {
    // Public member ----------------------------------------------------------
    this.Listen = Listen;
    function Listen(web_socket) {
        this.ListenCalendar(web_socket);
        this.ListenButton(web_socket);
        // this.ListenPlanRequest(web_socket);
       // this.ListenResetButton();
    }
    this.ReListenCalendar = ReListenCalendar;
    function ReListenCalendar() {
//        $('table.scalendar td div:not([date=])').css('position','relative').unbind('mousedown');
        $('table.scalendar td div').unbind('mouseup'); // remove mouse-up listener.
        this.ListenCalendar();
    }
    this.set_plan_inserter = set_plan_inserter;
    function set_plan_inserter(plan_inserter) {
        segment_type_listener.plan_inserter = plan_inserter;

    }
    // Private member ---------------------------------------------------------
    this.ListenCalendar = ListenCalendar;
    function ListenCalendar(web_socket) {
        this.CalendarEvent(web_socket);
    }
    this.ListenButton = ListenButton;
    function ListenButton(web_socket) {
        this.ButtonEvent(web_socket);
    }
    // Declare event listener function.
    this.CalendarEvent = CalendarEvent;
    function CalendarEvent() {
        $('table.scalendar td div:not([date=])').mouseup(function(element) {
            // Avoid doubly trigger
            var cell_set = $('table.scalendar td div:not([date=])');
            console.log(cell_set.length);
            var target = $(element.currentTarget);
            cell_set.find('div.active').remove();
            target.append(
                $('<div class="active"></div>').css({
                    width:'100%',
                    height:'100%',
                    backgroundColor:'#EFEFEF',
                    position:'absolute',
                    top:0,
                    left:0,
                    opacity:0.5
                }).attr('selected12','yes')
            );
//            $('#centerview').find('table.table.mainbody>tbody').empty();
            var date = $(element.currentTarget).attr('date');
            var crossroad = $(".crossroad option:selected").text();
            var segment_type = $(element.currentTarget).parent().attr("segment_type");
            console.log(segment_type);
            PaintButtonBackground(segment_type);
            //CalendarBackgroundColor();
            //ConnectNodeJS(date, crossroad);
        } );
    }
    this.ButtonEvent = ButtonEvent;
    function ButtonEvent(web_socket) { // listen segtype button
        $('ul.segtype_tab li').mouseup(function(element){
            $('table.scalendar td div:not([date=])').find('div.active').remove();
            var segment_type = $(element.currentTarget).find("a").attr("segment_type");
            var domain_select = $("select.intersection").find("option:selected");
            var int_id = domain_select.attr("mark");
       // Add active attribute to convenient upload listener to check which segment type should send.
       // 1. remove active attribute that before constructed by.
            PaintButtonBackground(segment_type);
       // 2. request tod_plan from DB and query priority data from tc (BF42)
            RequestTodData(int_id, segment_type, web_socket);
        });
    }
    this.PaintButtonBackground = PaintButtonBackground;
    function PaintButtonBackground(segment_type) {
        $('ul.segtype_tab li').find("a").css("backgroundColor", "#ffffff");
        var find_text = "a[segment_type=" + segment_type + "]";
        var target = $("ul.segtype_tab li").find(find_text);
        // console.log(target);
        target.css({
            backgroundColor:'#EFEFEF'
        });

       $('ul.segtype_tab li').find("a").attr("active", "false");
       target.attr("active", "true");
    }

    function RequestTodData(int_id, segment_type, web_socket){
      RequestTod(int_id, segment_type, web_socket);
      QueryBF42(int_id, segment_type, web_socket);
      function QueryBF42(int_id, segment_type, web_socket) { // query priority switch
        var query_json={};
        query_json.FunctionNo ='BF';
        query_json.MsgTypeNo ='42';
        query_json.LCN =int_id;
        query_json.MsgTime =TimeCreate.get_date_time();
        query_json.SegmentType =segment_type;
        console.log(query_json);
        web_socket.Send(query_json);
      }
      function RequestTod(int_id, segment_type, web_socket){
        var json_data={};
        json_data.FunctionNo ='request';
        json_data.MsgTypeNo ='todplan';
        json_data.LCN =int_id;
        json_data.Segtype =segment_type;
        // var json = JSON.stringify(json_data);
        console.log(json_data);
        web_socket.Send(json_data);
      }
      $('#progress_plan').attr('style', 'width: 20%');
         CheckTimeout();

      function QuerySegType(web_socket){
        var json_data={};
        json_data.FunctionNo ='query';
        json_data.MsgTypeNo ='segtype';
        json_data.LCN =int_id;
        // var json = JSON.stringify(json_data);
        // console.log(json);
        web_socket.Send(json_data);
      }
      function CheckTimeout(){
       setTimeout(function (){
           var success_count =$('#progress_seg')[0].attributes[6].value;
           if(success_count === 'width: 20%'){
            $('.progress').hide();
            $('#connect_fail').show();
               console.log('Time out: web socket');
           }else{}
       }, 60000);
      }
    }


   this.ListenResetButton = ListenResetButton;
   function ListenResetButton() {
      var domain = $("span.icon-repeat.reset_button");
      domain.click(function(){
         var segment_type = GetCurrentSegmentType();
         TriggerInserter(segment_type);
      });

   }

   this.GetCurrentSegmentType = GetCurrentSegmentType;
   function GetCurrentSegmentType() {
      var segment_type;
      var target;
      var button_set = $('ul.segtype_tab li').find("a");
      for (var button_index = 0; button_index < button_set.length; ++button_index) {
         target = $(button_set[button_index]);
         if ( target.attr("active") ==  "true") {
            segment_type = target.attr("segment_type");
            return segment_type;
         }
      }
      return -1;
   }

}