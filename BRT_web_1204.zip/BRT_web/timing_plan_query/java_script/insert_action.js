/**
 * Created by CCT on 2014/3/4.
 */

function InsertAction() {
   // Public member ----------------------------------------------------------
   this.set_tod_data = set_tod_data;
   function set_tod_data(tod_data) {
      this.data_modify.plan = transfer.DayToSection(tod_data);
   }
   this.set_standard_data = set_standard_data;
   function set_standard_data(standard_data) {
       if (standard_data.length != 0)
      this.data_modify.standard = transfer.PlanToSection(standard_data);
   }
   this.set_phase_list = set_phase_list;
   function set_phase_list(phase_list) {
      // this.data_modify.phase_list = transfer.PhaseToSection(phase_list);
      // this.FillPhaseList(this.data_modify.phase_list);
//        console.log(this.data_modify.phase_list);
   }
   this.set_priority_data = set_priority_data;
   function set_priority_data(priority_data) {
      this.data_modify.priority = transfer.PriorityToSection(priority_data);
   }
   this.Insert = Insert;
   function Insert(input_data, web_socket) {
      var domain_select = $("select.intersection").find("option:selected");
      var int_id = domain_select.attr("mark");
      var seg_selected = $('li a[active="true"]')[0].attributes.segment_type.value;
      var seg = parseInt(seg_selected);
      var lcn = parseInt(int_id);
      console.log(lcn+' '+seg);
      if(input_data.LCN === lcn && input_data.SegmentType === seg){
         for(var tod_index=0; tod_index < input_data.todList.length; ++tod_index){
            var current_tod = input_data.todList[tod_index];
            this.FillSpecificContent(tod_index, current_tod, web_socket);
         }
      }else{
         console.log('wrong container.');
      }
   }
   this.InsertTable = InsertTable;
   function InsertTable(data_type, result_content, web_socket){
      switch(data_type){
         case 'priorityplan':
            show_priorityplan(result_content);
            break;
         case 'stdplan':
            show_std(result_content);
            break;
         case 'phase':
            show_phase(result_content);
            break;
         default:
            break;
      }
   }

   this.FillSpecificContent = FillSpecificContent;
   function FillSpecificContent(tod_index, tod_data, web_socket) {
      var domain_table_body = $('#plan_table');
      var str_tbody = '';
      str_tbody += '<tr mark="'+tod_data.plan_id+'">';
      if(tod_data.priority_switch ===1){
         str_tbody += '<td><button class="btn btn-danger" disabled>優</button></td>';
      }else if(tod_data.priority_switch ===0){
         str_tbody += '<td><button class="btn btn-warning" disabled>定</button></td>';
      }else{
         console.log('priority_switch is undefined: '+tod_data.priority_switch);
      }
      str_tbody += '<td><button class="btn btn-default" disabled><span class"glyphicon glyphicon-time"></span>'+tod_data.begin_time+'</button></td>';
      str_tbody += '<td><span class="label label-primary">'+tod_data.plan_id+'</span></td>';
      str_tbody += '<td id="td_phase"></td><td id="td_plan"></td>';
      str_tbody += '</tr>';
      domain_table_body.append(str_tbody);
      var domain_tod =$('tbody#plan_table tr')[tod_index];
      domain_tod.onclick = function () {
         $('.progress').show();
         $('#progress_plan').attr('style', 'width: 20%');
         // console.log(this);
         var mark = this.attributes.mark.value;
         var planid = parseInt(mark);
         var domain_select = $("select.intersection").find("option:selected");
         var int_id = domain_select.attr("mark");
         var query_plan_data = {};
         query_plan_data.FunctionNo = 'query';
         query_plan_data.MsgTypeNo = 'plan';
         query_plan_data.LCN = int_id;
         query_plan_data.plan_id = planid;
         // var data_json = JSON.stringify(query_plan_data);
         // console.log(data_json);
         web_socket.Send(query_plan_data);
         var domain_td_phase = $('tr[mark ="'+planid+'"] td#td_phase');
         domain_td_phase.empty();
         var domain_td_plan = $('tr[mark ="'+planid+'"] td#td_plan');
         domain_td_plan.empty();
      QueryBF43(int_id, planid, web_socket);
      function QueryBF43(int_id, planid, web_socket) { // query priority switch
        var query_json={};
        query_json.FunctionNo ='BF';
        query_json.MsgTypeNo ='43';
        query_json.LCN =int_id;
        query_json.PlanID = planid;
        query_json.MsgTime =TimeCreate.get_date_time();
        console.log(query_json);
        web_socket.Send(query_json);
      }
      };
   }

   function show_phase(result_content){
      $('.progress').hide();
      $('#progress_plan').attr('style', 'width: 0%');
      var plan_id = result_content.plan_id;
      var domain_td_phase = $('tr[mark ="'+plan_id+'"] td#td_phase');
      // domain_td_phase.empty();
      var str_td_phase = '';
      str_td_phase += '<tr><td><button class="btn btn-default" disabled>'+result_content.phase_no+' '+result_content.phase_name+'</button></td></tr>';
      str_td_phase += '<tr><td>分相數: '+result_content.phase_total+' 步階數: '+result_content.phase_step+'</td></tr>';
      domain_td_phase.prepend(str_td_phase);
   }

   function show_std(result_content){
      var plan_id = result_content.plan_id;
      var domain_td_plan = $('tr[mark ="'+plan_id+'"] td#td_plan');
      // domain_td_plan.empty();
      var str_td_std = '';
      str_td_std += '<tr><th>分相</th><th>1</th><th>2</th><th>3</th><th>4</th><th>5</th><th>6</th></tr>';
      var col_name = ['allred', 'g', 'yellow', 'pred', 'pgflash', 'ming', 'maxg'];
      var col_string = ['紅', '綠', '黃', '行人紅', '行綠閃', '最小綠', '最大綠'];
      for(var col_index=0; col_index<7; ++col_index){
         var pr_prefix = col_name[col_index];
         str_td_std +='<tr><th>'+col_string[col_index]+'</th>';
         for(var std_index=0; std_index<6; ++std_index){
            var pr_name = pr_prefix + (std_index+1);
            str_td_std += '<td>'+result_content[pr_name]+'</td>';
         }
         str_td_std += '</tr>';
      }
      domain_td_plan.prepend(str_td_std);

      var domain_td_phase = $('tr[mark ="'+plan_id+'"] td#td_phase');
      var str_td_std_left='';
      str_td_std_left += '<tr><td>週期: '+result_content.cycletime+'</td></tr>';
      str_td_std_left += '<tr><td>時差: '+result_content.time_offset+'</td></tr>';
      domain_td_phase.prepend(str_td_std_left);
   }

   function show_priorityplan(result_content){
      var plan_id = result_content.priority_id;
      var domain_td_plan = $('tr[mark ="'+plan_id+'"] td#td_plan');
      var str_td_std_prior ='';
      var col_name = ['past_east', 'past_west', 'percentage_east', 'percentage_west'];
      var col_string = ['通行 東向', '通行 西向', '折減比例 東向', '折減比例 西向'];
      var past_east = result_content.past_east.split("").reverse().join("");
      var new_past_east ='';
      if(past_east.length !==6){
         var num = (6 - past_east.length);
         var z = '';
         for(var i=0; i<num; ++i){
            z+='0';
         }
         new_past_east = past_east.concat("", z);
      }
      var past_west = result_content.past_west.split("").reverse().join("");
      var new_past_west ='';
      if(past_west.length !==6){
         var num = (6 - past_west.length);
         var z = '';
         for(var i=0; i<num; ++i){
            z+='0';
         }
         new_past_west = past_west.concat("", z);
      }

      for(var col_index=0; col_index<4; ++col_index){
         var pr_prefix = col_name[col_index];
         str_td_std_prior +='<tr><th>'+col_string[col_index]+'</th>';
         for(var std_index=0; std_index<6; ++std_index){
            if(col_index ===0){
               var bool = new_past_east.charAt(std_index);
               str_td_std_prior += (bool === '1' ? '<td>可行</td>' : '<td> - </td>');
            }else if(col_index ===1){
               var bool = new_past_west.charAt(std_index);
               str_td_std_prior += (bool === '1' ? '<td>可行</td>' : '<td> - </td>');
            }else{
               var pr_name = pr_prefix + (std_index+1);
               str_td_std_prior += '<td>'+result_content[pr_name]+'</td>';
            }
         }
         str_td_std_prior += '</tr>';
      }
      domain_td_plan.append(str_td_std_prior);

      var domain_td_phase = $('tr[mark ="'+plan_id+'"] td#td_phase');
      var str_td_prior_left='';
      str_td_prior_left += '<tr><td>車門觸動時間 上行: '+result_content.door_trigger_up+'</td></tr>';
      str_td_prior_left += '<tr><td>車門觸動時間 下行: '+result_content.door_trigger_down+'</td></tr>';
      str_td_prior_left += '<tr><td>落後班距 上行: '+result_content.headway_up+'</td></tr>';
      str_td_prior_left += '<tr><td>落後班距 下行: '+result_content.headway_down+'</td></tr>';
      str_td_prior_left += '<tr><td>低速門檻值: '+result_content.lowspeed+'</td></tr>';
      domain_td_phase.append(str_td_prior_left);
   }






   this.set_specific_tod_data = set_specific_tod_data;
   function set_specific_tod_data(tod_data) {
      this.specific.tod = tod_data;
   }
   this.set_specific_std_data = set_specific_std_data;
   function set_specific_std_data(std_data) {
      this.specific.std = std_data;
   }
   this.set_specific_priority_data = set_specific_priority_data;
   function set_specific_priority_data(priority_data) {
      this.specific.priority = priority_data;

   }
   this.InsertTOD = InsertTOD;
   function InsertTOD(tod_index) {
      console.log("Insert time of day");
      var tod_data = this.specific.tod;
//        console.log(tod_data);
//        for (var tod_index = 0; tod_index < tod_data.length; ++tod_index) {
      var is_new_plan = true;
      var plan_id = tod_data[tod_index].plan_id;
      var begin_time = tod_data[tod_index].begin_time;
      // Check plan is new or not.
      var std_data = this.data_modify.standard;
      for (var std_index = 0; std_index < std_data.length; ++std_index) {
          if(typeof std_data[std_index] === 'undefined') continue;
         if (plan_id == std_data[std_index].plan_id) is_new_plan = false;
      }
      if (is_new_plan) {
         this.FillTableZeor(tod_index);
      } else {
         var standard_content = this.data_modify.standard[plan_id];
         this.FillPlanDetail(tod_index, standard_content);
         this.FillCalculationContent(tod_index, standard_content);
      }
   }

   this.InsertSpecificPlanContent = InsertSpecificPlanContent;
   function InsertSpecificPlanContent(table_index) {
      console.log("Insert plan content");
      var tod_data = this.specific.tod;
      var std_data = this.specific.std;
      var priority_data = this.specific.priority;
//        console.log(std_data);

      for (var tod_index = 0; tod_index < tod_data.length; ++tod_index) {
         if (std_data.plan_id != tod_data[tod_index].plan_id) continue;
//            console.log(tod_index);
         this.FillPlanDetail(tod_index, std_data);
         this.FillCalculationContent(tod_index, std_data);
         this.FillPriorityDetail(tod_index, priority_data);


      }


   }
   // Private member ---------------------------------------------------------
   this.data_modify = new Object();
   this.specific = new Object();
   var transfer = new TransferInputData();


   this.FillCalculationContent = FillCalculationContent;
   function FillCalculationContent(table_index, duration) {
      var table_id = '#timing_plan_table' + (table_index + 1);
      var domain = $(table_id);
      var phase_duration_total = [];
      var children = ["red", "green", "yellow"];
      var sum = 0;
      for (var phase_index = 0; phase_index < 6; ++phase_index) {
         sum = 0;
         for (var child_index = 0; child_index < children.length; ++child_index) {
            sum += Math.floor(duration[children[child_index]][phase_index]);
         }
         phase_duration_total[phase_index] = sum;
      }
      FillSequence(domain, phase_duration_total,  1, 6);
      var period = 0
      for (var phase_index = 0; phase_index < 6; ++phase_index) {
         period += phase_duration_total[phase_index];
      }
      FillUnit(domain, period, 7);

   }

   this.FillPlanDetail = FillPlanDetail;
   function FillPlanDetail(table_index, content) {
      var table_id = '#timing_plan_table' + (table_index + 1);
      var domain = $(table_id);
      domain.show();
      FillSequence(domain, content.red   ,  9, 14);
      FillSequence(domain, content.green , 15, 20);
      FillSequence(domain, content.yellow, 21, 26);
      FillSequence(domain, content.green_p      , 27, 32);
      FillSequence(domain, content.green_p_flash, 33, 38);
      FillSequence(domain, content.green_min, 39, 44);
      FillSequence(domain, content.green_max, 45, 50);
      var find_cmd = "option[no=" + content.phase_no + "]";
      domain.find(".phase_list").find(find_cmd).attr("selected", true);
      FillUnit(domain, content.offset, 8);
   }

   this.FillPriorityDetail = FillPriorityDetail;
   function FillPriorityDetail(table_index, content) {
      var table_id = '#timing_plan_table' + (table_index + 1);
      var domain = $(table_id);
      this.FillCheckbox(domain, "pass_east", content.past_east);
      this.FillCheckbox(domain, "pass_west", content.past_west);
      FillSequence(domain, content.percentage_east, 51, 56);
      FillSequence(domain, content.percentage_west, 57, 62);
      FillUnit(domain, content.door_trigger_up, 63);
      FillUnit(domain, content.door_trigger_down, 64);
      FillUnit(domain, content.headway_up, 65);
      FillUnit(domain, content.headway_down, 66);
      FillUnit(domain, content.lowspeed, 67);
   }

   this.FillTableZeor = FillTableZeor;
   function FillTableZeor(table_index) {
      var table_id = '#timing_plan_table' + (table_index + 1);
      var domain = $(table_id);
      for (var cell_index = 1; cell_index <= 50; ++cell_index) {
         FillUnit(domain, 0, cell_index);
      }
   }

   this.FillPhaseList = FillPhaseList;
   function FillPhaseList(phase_list) {
      for (var phase_index = 0; phase_index < phase_list.length; phase_index++) {
         var current_phase = phase_list[phase_index];
//         var hex_name = yourNumber.toString(16);
         var text_find = "<option index=" + phase_index + " no=" + current_phase.no + " total=" + current_phase.total + ">";
         text_find +=  current_phase.no +' '+ current_phase.name + ' 分相數: ' + current_phase.total +  "</option>";
         $("#plan_table").find("select.phase_list").append($(text_find));
      }
   }

   function FillSequence(domain, data, start, end) {
      var data_index = 0;
      for (var phase_index = start; phase_index <= end; ++phase_index) {
         var text_fine = "input[type=number]:eq(" + phase_index + ")";
         domain.find(text_fine).val(data[data_index]);
         ++data_index;
      }
   }
   function FillUnit(domain, data, index) {
      var text_fine = "input[type=number]:eq(" + index + ")";
      domain.find(text_fine).val(data);
   }

   this.FillCheckbox = FillCheckbox;
   function FillCheckbox(domain, label, data) {
//      console.log("fill checkbox" + data);
      for (var index = 0; index < data.length; index++) {
         var text_find = 'tr.' + label + " input[type=checkbox]:eq("+ index +")";
         var checked = $(domain).find(text_find).prop('checked', data[index]);
      }
   }

   this.HideTableAll = HideTableAll;
   function HideTableAll() {
      for (var table_index = 0; table_index < 32; table_index++) {
         var table_id = '#timing_plan_table' + (table_index + 1);
         var domain = $(table_id);
         if (domain.length == 0) continue;
         domain.css("display", "none");
      }
   }

   this.ShowTable = ShowTable;
   function ShowTable(table_index) {
      var table_id = '#timing_plan_table' + (table_index + 1);
      var domain = $(table_id);
      domain.css("display", "");
   }

}
