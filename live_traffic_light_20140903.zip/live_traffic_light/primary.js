/**
 * Created by HongYu on 2014/4/9.
 * Modified by HongYu on 2014/9/1
 */

var live_data_manager = require("./data_manager.js");
live_data_manager.Initialize(3);
var live_tl_info = require("./traffic_light_information.js");
var data_process = require("./data_process.js");
data_process.Initialize();
module.exports = {
    Initialize: function() {
//        this.light_converter = light_converter;
//        this.data_manage = live_data_manager;
//        this.tl_info = live_tl_info;
//        var pole_info = this.tl_info;
//        pole_info.set_connector(this.con_db);
//        pole_info.set_data_manager(this.data_manage);
//        pole_info.Data();
    },
    set_connector: function (con_db) {
        this.con_db = con_db;
        data_process.set_connector(this.con_db);
        data_process.Build();
    },
    Receive: function () {
    },
    UpdateStatus: function(input_data) {
        data_process.Update(input_data);
//        UpdateStatus(this.con_db, this.light_converter, input_data, this.data_manage);
    },
    SendStatus: function(web_socket) {
        function CycleLight() {
            if(web_socket.readyState == 3) return; // stop when disconnect.
            SendToWebsite(web_socket);
            setTimeout(arguments.callee, 2000);
        }
        CycleLight();
    }
};



//function UpdateStatus2 (db_connector, light_converter, input_data, data_manage) {
//
//    var card_data = input_data;
////         console.log(card_data);
//    var light_detail = [];
//    var light_single = [];
//    var light_card_detail = [];
//    for (var card_index = 0; card_index < 6; card_index++) {
//        light_converter.Convert(input_data);
//        light_detail[card_index] = light_converter.get_detail();
//        light_single[card_index] = light_converter.get_single();
//        light_card_detail[card_index] = light_converter.get_card_detail();
//    }
//    var equip_id = card_data.equip_id;
////         console.log(equip_id);
//    var intersection_id = 5;
//    var sql_cmd = 'Select serial_number from intersection ';
//    sql_cmd += "Where intersection_id = " + intersection_id;
//    var query = db_connector.query(sql_cmd);
//    query.exec( function( err, res ){
//        if( err ){
//            console.log('read traffic light error\n');
//            console.log(err);
//            return
//        }else{
////               result.info = res.result;
//            var section_index = res.result[0].serial_number;
////               console.log(section_index);
//            data_manage.set_lights(section_index, light_detail, light_single, light_card_detail);
////               data_manage.Show();
////         console.log('database connect success,\n');
//        }
//    });
//
//}

function SendToWebsite(web_socket) {
    var light_info= new Object();
    light_info.FunctionNo = "light_status";
    light_info.MsgTypeNo = "response";
    light_info.MsgTime = CurrentTime();
    light_info.info = data_process.get_live_light();
    var json_data = JSON.stringify(light_info);
    web_socket.send(json_data);

}



function CurrentTime(){
    var d = new Date();
    var month = d.getMonth()+1;
    var day = d.getDate();
    var hours = d.getHours();
    var minutes = d.getMinutes();
    var seconds = d.getSeconds();
    var output = d.getFullYear()+'-'+(month<10 ? '0' : '')+month+'-'+(day<10 ? '0' : '')+day+" "+(hours<10 ? '0' : '')+hours+":"+(minutes<10 ? '0' : '')+minutes+":"+(seconds<10 ? '0' : '')+seconds;
    return output;
}

function RandomLight() {
    function Structure(intersection_id, equip_id, card_id, traffic_type, light, detail, rotation, longitude, latitude) {
        this.intersection_id = intersection_id;
        this.equip_id = equip_id;
        this.card_id = card_id;
        this.traffic_type = traffic_type;
        this.light = light;
        this.detail = detail;
        this.rotation = rotation;
        this.longitude = longitude;
        this.latitude = latitude;
    }
    var intersection_id = 1;
    var equip_id = 1;
    var card_id = 1;
    var traffic_type = 1;
    var light = Math.floor((Math.random()*3));
    var right = Math.floor((Math.random()*3));
    var straight = Math.floor((Math.random()*3));
    var left = Math.floor((Math.random()*3));
    var detail = "" + left + straight + right;
    var rotation = 270;
    var longitude = traffic_info.info[0].longitude;
    var latitude = traffic_info.info[0].latitude;
}
